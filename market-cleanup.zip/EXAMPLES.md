# 📚 Market Cleanup 사용 예제

**실전 코드 예제 모음** 💻✨

---

## 🎯 **기본 사용 예제**

### **1. ProductDetailPage에서 삭제 버튼**

```typescript
// src/pages/ProductDetailPage.tsx
import { useDeleteProduct } from "@/hooks/useDeleteProduct";

export default function ProductDetailPage() {
  const { id } = useParams();
  const [product, setProduct] = useState<any>(null);
  const { deleteProduct, isDeleting } = useDeleteProduct();

  // 상품 데이터 불러오기
  useEffect(() => {
    const fetchProduct = async () => {
      const snap = await getDoc(doc(db, "marketItems", id!));
      if (snap.exists()) {
        setProduct({ id: snap.id, ...snap.data() });
      }
    };
    fetchProduct();
  }, [id]);

  // 삭제 핸들러
  const handleDelete = () => {
    deleteProduct(product);
    // 삭제 완료 후 /market으로 자동 이동
  };

  return (
    <div>
      <h1>{product?.title}</h1>
      <img src={product?.imageUrl} alt={product?.title} />
      <p>{product?.desc}</p>

      <button
        onClick={handleDelete}
        disabled={isDeleting}
        className="bg-red-500 text-white px-4 py-2 rounded"
      >
        {isDeleting ? "삭제 중..." : "🗑️ 상품 삭제"}
      </button>
    </div>
  );
}
```

---

## 🎨 **고급 UI 예제**

### **2. 확인 다이얼로그 + 로딩 상태**

```typescript
import { useDeleteProduct } from "@/hooks/useDeleteProduct";
import { Loader2, Trash2 } from "lucide-react";

export default function ProductCard({ product }: { product: any }) {
  const { deleteProduct, isDeleting } = useDeleteProduct();

  const handleDelete = async () => {
    const result = await deleteProduct(
      product,
      `"${product.title}"을(를) 정말 삭제하시겠습니까?\n\n이 작업은 되돌릴 수 없습니다.`,
      "/my-products" // 삭제 후 내 상품 목록으로 이동
    );

    if (result.success) {
      console.log("✅ 삭제 완료");
    } else if (result.cancelled) {
      console.log("ℹ️ 사용자가 취소함");
    }
  };

  return (
    <div className="border rounded-lg p-4">
      <h3>{product.title}</h3>
      <p>{product.price.toLocaleString()}원</p>

      <button
        onClick={handleDelete}
        disabled={isDeleting}
        className="flex items-center gap-2 bg-red-100 hover:bg-red-200 text-red-700 px-4 py-2 rounded-lg disabled:opacity-50"
      >
        {isDeleting ? (
          <>
            <Loader2 size={16} className="animate-spin" />
            <span>삭제 중...</span>
          </>
        ) : (
          <>
            <Trash2 size={16} />
            <span>삭제</span>
          </>
        )}
      </button>
    </div>
  );
}
```

---

## 📋 **일괄 삭제 예제**

### **3. 체크박스 선택 + 일괄 삭제**

```typescript
import { useState } from "react";
import { useDeleteProduct } from "@/hooks/useDeleteProduct";

export default function MyProductsPage() {
  const [products, setProducts] = useState<any[]>([]);
  const [selectedIds, setSelectedIds] = useState<string[]>([]);
  const { deleteMultipleProducts, isDeleting } = useDeleteProduct();

  const handleSelectAll = () => {
    if (selectedIds.length === products.length) {
      setSelectedIds([]);
    } else {
      setSelectedIds(products.map((p) => p.id));
    }
  };

  const handleToggleSelect = (id: string) => {
    setSelectedIds((prev) =>
      prev.includes(id) ? prev.filter((i) => i !== id) : [...prev, id]
    );
  };

  const handleBulkDelete = async () => {
    const selectedProducts = products.filter((p) =>
      selectedIds.includes(p.id)
    );

    const result = await deleteMultipleProducts(selectedProducts);

    if (result.success) {
      console.log(`✅ ${result.successCount}개 삭제 완료`);
      // 상품 목록 새로고침
      fetchProducts();
      setSelectedIds([]);
    }
  };

  return (
    <div>
      <div className="flex justify-between items-center mb-4">
        <h1 className="text-2xl font-bold">내 상품 관리</h1>

        <div className="flex gap-2">
          <button
            onClick={handleSelectAll}
            className="px-4 py-2 border rounded"
          >
            {selectedIds.length === products.length
              ? "선택 해제"
              : "전체 선택"}
          </button>

          {selectedIds.length > 0 && (
            <button
              onClick={handleBulkDelete}
              disabled={isDeleting}
              className="px-4 py-2 bg-red-500 text-white rounded disabled:opacity-50"
            >
              {isDeleting
                ? "삭제 중..."
                : `선택 항목 삭제 (${selectedIds.length})`}
            </button>
          )}
        </div>
      </div>

      <div className="space-y-2">
        {products.map((product) => (
          <div key={product.id} className="flex items-center gap-4 p-4 border">
            <input
              type="checkbox"
              checked={selectedIds.includes(product.id)}
              onChange={() => handleToggleSelect(product.id)}
            />
            <img
              src={product.imageUrl}
              alt={product.title}
              className="w-16 h-16 object-cover"
            />
            <div className="flex-1">
              <h3>{product.title}</h3>
              <p>{product.price.toLocaleString()}원</p>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
```

---

## 🔒 **권한 체크 예제**

### **4. 판매자 본인만 삭제 가능**

```typescript
import { useDeleteProduct } from "@/hooks/useDeleteProduct";
import { useAuth } from "@/hooks/useAuth";

export default function ProductDetailPage() {
  const { product } = useProduct();
  const { user } = useAuth();
  const { deleteProduct, isDeleting } = useDeleteProduct();

  // 판매자 본인인지 체크
  const isOwner = user?.uid === product?.sellerUid;

  const handleDelete = () => {
    if (!isOwner) {
      alert("본인 상품만 삭제할 수 있습니다.");
      return;
    }

    deleteProduct(product);
  };

  return (
    <div>
      <h1>{product?.title}</h1>

      {/* 판매자 본인에게만 표시 */}
      {isOwner && (
        <div className="mt-4 p-4 bg-gray-50 rounded-lg">
          <h2 className="font-bold mb-2">👑 판매자 관리 메뉴</h2>

          <button
            onClick={handleDelete}
            disabled={isDeleting}
            className="w-full bg-red-100 hover:bg-red-200 text-red-700 px-4 py-2 rounded-lg"
          >
            {isDeleting ? "삭제 중..." : "🗑️ 상품 삭제"}
          </button>
        </div>
      )}
    </div>
  );
}
```

---

## 🔔 **토스트 알림 예제**

### **5. 삭제 완료 시 토스트 알림**

```typescript
import { useDeleteProduct } from "@/hooks/useDeleteProduct";
import { toast } from "react-hot-toast";

export default function ProductCard({ product }: { product: any }) {
  const { deleteProduct, isDeleting } = useDeleteProduct();

  const handleDelete = async () => {
    // 삭제 시작 알림
    const toastId = toast.loading("상품을 삭제하는 중...");

    try {
      const result = await deleteProduct(product);

      if (result.success) {
        toast.success("상품이 삭제되었습니다.", { id: toastId });
      } else if (result.cancelled) {
        toast.dismiss(toastId);
      } else {
        toast.error("삭제 중 오류가 발생했습니다.", { id: toastId });
      }
    } catch (error) {
      toast.error("삭제 중 오류가 발생했습니다.", { id: toastId });
    }
  };

  return (
    <button onClick={handleDelete} disabled={isDeleting}>
      🗑️ 삭제
    </button>
  );
}
```

---

## 🧪 **테스트 예제**

### **6. Jest/Vitest 단위 테스트**

```typescript
import { renderHook, act } from "@testing-library/react";
import { useDeleteProduct } from "@/hooks/useDeleteProduct";
import { deleteDoc } from "firebase/firestore";
import { deleteObject } from "firebase/storage";

// Mock Firebase
jest.mock("firebase/firestore");
jest.mock("firebase/storage");

describe("useDeleteProduct", () => {
  it("상품을 정상적으로 삭제합니다", async () => {
    const { result } = renderHook(() => useDeleteProduct());

    const mockProduct = {
      id: "test123",
      title: "테스트 상품",
      imagePath: "market-images/test.jpg",
    };

    // confirm 모킹
    window.confirm = jest.fn(() => true);

    await act(async () => {
      const response = await result.current.deleteProduct(mockProduct);
      expect(response.success).toBe(true);
    });

    // Firebase 함수가 호출되었는지 확인
    expect(deleteObject).toHaveBeenCalled();
    expect(deleteDoc).toHaveBeenCalled();
  });

  it("사용자가 취소하면 삭제하지 않습니다", async () => {
    const { result } = renderHook(() => useDeleteProduct());

    const mockProduct = { id: "test123" };
    window.confirm = jest.fn(() => false);

    await act(async () => {
      const response = await result.current.deleteProduct(mockProduct);
      expect(response.cancelled).toBe(true);
    });

    expect(deleteObject).not.toHaveBeenCalled();
    expect(deleteDoc).not.toHaveBeenCalled();
  });
});
```

---

## 📊 **관리자 대시보드 예제**

### **7. 관리자용 강제 삭제**

```typescript
import { useDeleteProduct } from "@/hooks/useDeleteProduct";
import { Shield } from "lucide-react";

export default function AdminProductManagement() {
  const [products, setProducts] = useState<any[]>([]);
  const { deleteProduct } = useDeleteProduct();

  // 관리자 강제 삭제 (확인창 없음)
  const handleAdminDelete = async (product: any) => {
    const confirmed = window.confirm(
      `⚠️ 관리자 권한으로 삭제합니다.\n\n상품: ${product.title}\n판매자: ${product.sellerUid}\n\n정말 삭제하시겠습니까?`
    );

    if (!confirmed) return;

    await deleteProduct(product, undefined, "/admin/products");
  };

  return (
    <div>
      <h1 className="text-2xl font-bold mb-4">
        <Shield className="inline mr-2" />
        관리자 상품 관리
      </h1>

      <table className="w-full">
        <thead>
          <tr>
            <th>상품명</th>
            <th>판매자</th>
            <th>등록일</th>
            <th>작업</th>
          </tr>
        </thead>
        <tbody>
          {products.map((product) => (
            <tr key={product.id}>
              <td>{product.title}</td>
              <td>{product.sellerUid}</td>
              <td>{product.createdAt?.toDate().toLocaleDateString()}</td>
              <td>
                <button
                  onClick={() => handleAdminDelete(product)}
                  className="text-red-600 hover:underline"
                >
                  강제 삭제
                </button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
```

---

## 🎉 **완성!**

**모든 실전 시나리오를 커버하는 예제 모음!** 📚✨

**포함된 예제:**
- ✅ 기본 삭제 버튼
- ✅ 고급 UI (로딩 상태)
- ✅ 일괄 삭제
- ✅ 권한 체크
- ✅ 토스트 알림
- ✅ 단위 테스트
- ✅ 관리자 대시보드

**형님의 프로젝트에 복사해서 바로 사용하세요!** 🚀

**YAGO VIBE - 실전 예제 완성! ✅⚽💻**

