# 🧹 YAGO VIBE - Market Storage Auto Cleanup

**상품 삭제 시 Storage 이미지 자동 정리 시스템** 💰✨

---

## 📦 **패키지 구성**

```
market-cleanup/
├── src/
│   └── hooks/
│       └── useDeleteProduct.ts    ← 프런트엔드 훅 (즉시 삭제)
├── functions/
│   ├── index.js                   ← 백엔드 자동 클린업 (JavaScript)
│   └── index.ts                   ← 백엔드 자동 클린업 (TypeScript)
└── README.md                      ← 이 파일
```

---

## 🎯 **주요 기능**

### **1️⃣ 프런트엔드 즉시 삭제 (useDeleteProduct Hook)**
- ✅ 상품 삭제 시 Storage 이미지 즉시 삭제
- ✅ Firestore 문서 삭제
- ✅ 에러 핸들링 (이미 삭제된 파일 무시)
- ✅ 사용자 친화적 (확인창, 로딩 상태)

### **2️⃣ 백엔드 자동 클린업 (Firebase Functions)**
- ✅ Firestore 문서 삭제 감지 시 자동 실행
- ✅ Storage 이미지 자동 삭제
- ✅ 네트워크 장애 시 백업
- ✅ 완전 자동화

---

## 🚀 **설치 방법**

### **Step 1: 프런트엔드 훅 설치**

```bash
# 1. useDeleteProduct.ts를 프로젝트에 복사
cp market-cleanup/src/hooks/useDeleteProduct.ts src/hooks/

# 2. 필요한 패키지 확인 (이미 설치되어 있을 것)
# - firebase
# - react-router-dom
```

### **Step 2: Firebase Functions 설치**

```bash
# JavaScript 프로젝트인 경우
cp market-cleanup/functions/index.js functions/src/

# TypeScript 프로젝트인 경우
cp market-cleanup/functions/index.ts functions/src/

# 또는 기존 functions/src/index.ts에 내용 추가
```

### **Step 3: Functions 배포**

```bash
cd functions
npm install firebase-functions firebase-admin
npm run build  # TypeScript인 경우
firebase deploy --only functions:cleanUpMarketImages
```

---

## 💻 **사용 방법**

### **1. 프런트엔드에서 사용**

#### **기본 사용법**
```typescript
import { useDeleteProduct } from "@/hooks/useDeleteProduct";

function ProductDetailPage() {
  const { deleteProduct, isDeleting } = useDeleteProduct();
  
  const handleDelete = () => {
    deleteProduct(product);
    // 삭제 완료 후 /market으로 자동 리다이렉트
  };

  return (
    <button 
      onClick={handleDelete}
      disabled={isDeleting}
    >
      {isDeleting ? "삭제 중..." : "🗑️ 상품 삭제"}
    </button>
  );
}
```

#### **고급 사용법 (커스텀 설정)**
```typescript
const handleDelete = () => {
  deleteProduct(
    product,
    "정말 삭제하시겠습니까?",  // 커스텀 확인 메시지
    "/my-products"              // 커스텀 리다이렉트 경로
  );
};
```

#### **일괄 삭제**
```typescript
const { deleteMultipleProducts, isDeleting } = useDeleteProduct();

const handleBulkDelete = () => {
  deleteMultipleProducts(selectedProducts);
};
```

### **2. Functions 작동 확인**

```bash
# Functions 로그 실시간 확인
firebase functions:log --only cleanUpMarketImages

# 예상 출력:
# 🧹 상품 삭제 감지: abc123
# ✅ Storage 이미지 삭제 완료: market-images/1234567890_shoe.jpg
```

---

## 🧪 **테스트 방법**

### **1. 프런트엔드 삭제 테스트**
```bash
1. 판매자 계정으로 로그인
2. 자신의 상품 상세 페이지 접속
3. [🗑️ 상품 삭제] 버튼 클릭
4. 확인창에서 [확인] 클릭
5. 콘솔 확인:
   ✅ Storage 이미지 삭제 완료: market-images/...
   ✅ Firestore 문서 삭제 완료: abc123
6. Firebase Console 확인:
   - Firestore: 문서 삭제됨 ✅
   - Storage: 이미지 삭제됨 ✅
```

### **2. Functions 자동 클린업 테스트**
```bash
1. Firebase Console → Firestore
2. marketItems 컬렉션에서 문서 직접 삭제
3. Functions 로그 확인:
   🧹 상품 삭제 감지: abc123
   ✅ Storage 이미지 삭제 완료: market-images/...
4. Storage 확인: 이미지 삭제됨 ✅
```

---

## 🔄 **작동 흐름**

```
사용자가 상품 삭제 버튼 클릭
  ↓
useDeleteProduct 훅 실행
  ├─ 1단계: Storage 이미지 삭제 (프런트)
  └─ 2단계: Firestore 문서 삭제 (프런트)
  ↓
Firestore 문서 삭제 감지 (Functions)
  └─ 3단계: Storage 이미지 삭제 (백업)
       ├─ 이미 삭제됨 → 무시 (정상)
       └─ 남아있음 → 삭제 (복구)
  ↓
✅ 완전 삭제 완료
```

---

## 📊 **비용 절감 효과**

### **자동 삭제 없을 때:**
```
월 평균 상품 삭제: 80개
이미지 평균 크기: 2MB

1년 후:
- 누적 이미지: 960개
- 누적 용량: 1.92GB
- 예상 비용: $0.05 / 월

5년 후:
- 누적 용량: 9.6GB
- 예상 비용: $0.25 / 월 (~3,000원)
- 연간 비용: $3 (~40,000원)
```

### **자동 삭제 활성 시:**
```
Storage 사용량: 항상 최소 유지
- 활성 상품만 저장 (20개 평균)
- 누적 용량: 40MB (고정)
- 예상 비용: $0.001 / 월 (무료 티어 내)

✅ 5년간 절감: $15 (~200,000원)
```

---

## 🛡️ **안전 기능**

### **이중 안전 구조**
```
1️⃣ 프런트엔드 즉시 삭제
   → 사용자 경험 최적화
   → 즉각적인 피드백

2️⃣ Functions 자동 백업
   → 네트워크 장애 시 백업
   → 완전 자동화
```

### **에러 핸들링**
```typescript
// 이미 삭제된 파일 → 무시 (정상)
if (error.code === "storage/object-not-found") {
  console.log("ℹ️ 이미 삭제됨");
}

// 기타 에러 → 로그만 남기고 계속 진행
console.warn("⚠️ Storage 삭제 실패 (계속 진행)");
```

---

## 🔧 **고급 설정**

### **1. 여러 컬렉션 지원**

```typescript
// functions/src/index.ts

// 사용자 프로필 이미지 자동 정리
export const cleanUpUserImages = onDocumentDeleted(
  "users/{userId}",
  async (event) => {
    // ... (이미 포함되어 있음)
  }
);

// 채팅방 첨부 파일 자동 정리
export const cleanUpChatAttachments = onDocumentDeleted(
  "chatRooms/{roomId}",
  async (event) => {
    // ... (이미 포함되어 있음)
  }
);
```

### **2. 배포 명령어**

```bash
# 특정 함수만 배포
firebase deploy --only functions:cleanUpMarketImages
firebase deploy --only functions:cleanUpUserImages
firebase deploy --only functions:cleanUpChatAttachments

# 전체 함수 배포
firebase deploy --only functions

# 배포 확인
firebase functions:list
```

---

## 📝 **Firestore 데이터 구조**

### **필수 필드**
```typescript
{
  id: "abc123",
  imagePath: "market-images/1234567890_shoe.jpg", // ✅ 필수!
  imageUrl: "https://storage.googleapis.com/...",
  // ... 기타 필드
}
```

### **imagePath 저장 방법**

```typescript
// 상품 등록 시
const imagePath = `market-images/${Date.now()}_${image.name}`;
const storageRef = ref(storage, imagePath);
await uploadBytes(storageRef, image);

await addDoc(collection(db, "marketItems"), {
  imageUrl: await getDownloadURL(storageRef),
  imagePath, // ✅ 이 필드를 반드시 저장해야 함
  // ...
});
```

---

## 🐛 **문제 해결**

### **Q1: "imagePath 필드가 없습니다" 로그가 나옵니다**
```
A: Firestore 문서에 imagePath 필드를 추가해야 합니다.
   상품 등록 시 imagePath를 저장하는지 확인하세요.
```

### **Q2: Functions에서 "Permission denied" 에러**
```bash
A: Firebase Console → Storage → Rules 확인
   allow delete: if request.auth != null;
```

### **Q3: 프런트에서 삭제는 되는데 Functions 로그가 안 보입니다**
```bash
A: Functions가 배포되었는지 확인:
   firebase functions:list
   
   없으면 배포:
   firebase deploy --only functions:cleanUpMarketImages
```

---

## 📚 **추가 리소스**

- [Firebase Storage 문서](https://firebase.google.com/docs/storage)
- [Firebase Functions v2 문서](https://firebase.google.com/docs/functions/firestore-events)
- [Storage 요금 정책](https://firebase.google.com/pricing)

---

## 🎉 **완성!**

**YAGO VIBE - Market Storage Auto Cleanup 완성!** 🧹💰✨

**핵심 기능:**
- ✅ 프런트엔드 즉시 삭제
- ✅ Functions 자동 백업
- ✅ 이중 안전 구조
- ✅ 비용 최적화 (장기 ~100% 절감)
- ✅ 완전 자동화

**설치 후:**
```
1. 프런트엔드: useDeleteProduct 훅 복사
2. Functions: index.js/ts 복사 및 배포
3. 테스트: 상품 삭제 시 Storage 자동 정리 확인
4. 운영: 자동으로 Storage 깔끔하게 유지
```

**형님의 프로젝트에 바로 적용 가능합니다!** 🚀

**YAGO VIBE - 운영용 자동 정리 세트 완성! ✅⚽🧹💰**

