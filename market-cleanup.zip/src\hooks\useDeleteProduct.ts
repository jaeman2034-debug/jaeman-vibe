/**
 * 🗑️ 상품 삭제 훅 (Storage 자동 정리 포함)
 * 
 * 사용법:
 * ```typescript
 * const { deleteProduct, isDeleting } = useDeleteProduct();
 * 
 * <button onClick={() => deleteProduct(item)}>삭제</button>
 * ```
 */

import { deleteDoc, doc } from "firebase/firestore";
import { ref, deleteObject } from "firebase/storage";
import { getFirestore } from "firebase/firestore";
import { getStorage } from "firebase/storage";
import { getApp, initializeApp, getApps } from "firebase/app";
import { useNavigate } from "react-router-dom";
import { useState } from "react";

const firebaseConfig = {
  apiKey: import.meta.env.VITE_FIREBASE_API_KEY,
  authDomain: import.meta.env.VITE_FIREBASE_AUTH_DOMAIN,
  projectId: import.meta.env.VITE_FIREBASE_PROJECT_ID,
  storageBucket: import.meta.env.VITE_FIREBASE_STORAGE_BUCKET,
  messagingSenderId: import.meta.env.VITE_FIREBASE_MESSAGING_SENDER_ID,
  appId: import.meta.env.VITE_FIREBASE_APP_ID,
};

const app = getApps().length ? getApps()[0] : initializeApp(firebaseConfig);
const db = getFirestore(app);
const storage = getStorage(app);

export interface Product {
  id: string;
  title?: string;
  imageUrl?: string;
  imagePath?: string;
  [key: string]: any;
}

export function useDeleteProduct() {
  const navigate = useNavigate();
  const [isDeleting, setIsDeleting] = useState(false);

  /**
   * 상품 완전 삭제 (Storage 이미지 + Firestore 문서)
   * 
   * @param item - 삭제할 상품 객체 (id, imagePath 필드 필요)
   * @param confirmMessage - 사용자 확인 메시지 (옵션)
   * @param redirectPath - 삭제 후 이동할 경로 (기본값: /market)
   */
  const deleteProduct = async (
    item: Product, 
    confirmMessage?: string,
    redirectPath?: string
  ) => {
    // 확인 메시지
    const message = confirmMessage || 
      `정말로 "${item.title || "이 상품"}"을 삭제하시겠습니까?\n\n⚠️ 이미지와 모든 데이터가 영구적으로 삭제됩니다.\n이 작업은 되돌릴 수 없습니다.`;
    
    if (!window.confirm(message)) {
      return { success: false, cancelled: true };
    }

    setIsDeleting(true);

    try {
      // 🔹 1단계: Storage 이미지 삭제
      if (item.imagePath || item.imageUrl) {
        try {
          // imagePath 우선 사용
          let storagePath = item.imagePath;
          
          // imagePath가 없으면 imageUrl에서 추출
          if (!storagePath && item.imageUrl) {
            const urlMatch = item.imageUrl.match(/o\/(.*?)\?/);
            if (urlMatch) {
              storagePath = decodeURIComponent(urlMatch[1]);
            }
          }

          if (storagePath) {
            const imgRef = ref(storage, storagePath);
            await deleteObject(imgRef);
            console.log("✅ Storage 이미지 삭제 완료:", storagePath);
          }
        } catch (storageError: any) {
          // 이미지가 이미 삭제되었거나 없는 경우 무시
          if (storageError.code === "storage/object-not-found") {
            console.log("ℹ️ Storage 이미지가 이미 삭제되었거나 존재하지 않습니다.");
          } else {
            console.warn("⚠️ Storage 이미지 삭제 중 오류 (계속 진행):", storageError);
          }
        }
      }

      // 🔹 2단계: Firestore 문서 삭제
      await deleteDoc(doc(db, "marketItems", item.id));
      console.log("✅ Firestore 문서 삭제 완료:", item.id);

      // 성공 알림
      alert("상품과 이미지가 완전히 삭제되었습니다.");

      // 리다이렉트
      const targetPath = redirectPath || "/market";
      navigate(targetPath);

      return { success: true, cancelled: false };
    } catch (error) {
      console.error("❌ 상품 삭제 실패:", error);
      alert("삭제 중 오류가 발생했습니다. 다시 시도해주세요.");
      return { success: false, cancelled: false, error };
    } finally {
      setIsDeleting(false);
    }
  };

  /**
   * 여러 상품 일괄 삭제
   * 
   * @param items - 삭제할 상품 배열
   */
  const deleteMultipleProducts = async (items: Product[]) => {
    if (!window.confirm(`${items.length}개의 상품을 삭제하시겠습니까?`)) {
      return { success: false, cancelled: true };
    }

    setIsDeleting(true);

    try {
      const results = await Promise.allSettled(
        items.map(async (item) => {
          // Storage 이미지 삭제
          if (item.imagePath) {
            try {
              const imgRef = ref(storage, item.imagePath);
              await deleteObject(imgRef);
            } catch (error) {
              console.warn("Storage 삭제 실패:", item.id, error);
            }
          }

          // Firestore 문서 삭제
          await deleteDoc(doc(db, "marketItems", item.id));
        })
      );

      const successCount = results.filter((r) => r.status === "fulfilled").length;
      const failCount = results.filter((r) => r.status === "rejected").length;

      console.log(`✅ 일괄 삭제 완료: ${successCount}개 성공, ${failCount}개 실패`);
      alert(`${successCount}개의 상품이 삭제되었습니다.${failCount > 0 ? `\n(${failCount}개 실패)` : ""}`);

      return { success: true, successCount, failCount };
    } catch (error) {
      console.error("❌ 일괄 삭제 실패:", error);
      alert("일괄 삭제 중 오류가 발생했습니다.");
      return { success: false, error };
    } finally {
      setIsDeleting(false);
    }
  };

  return {
    deleteProduct,
    deleteMultipleProducts,
    isDeleting,
  };
}

